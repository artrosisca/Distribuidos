package model;

import com.google.gson.Gson;

public class Register {
    private int op; // Always 1 for register operation
    private String name; // User name (up to 40 characters)
    private String user; // User ID (7 digits)
    private String password; // Password (4 digits)

    public Register(String name, String user, String password) {
        this.op = 1; // Set operation as "Register"
        this.name = name;
        this.user = user;
        this.password = password;
    }

    public int getOp() {
        return op;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.length() > 40) {
            throw new IllegalArgumentException("The name must be at most 40 characters long.");
        }
        this.name = name;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        if (!user.matches("\\d{7}")) {
            throw new IllegalArgumentException("The user ID must be exactly 7 digits.");
        }
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (!password.matches("\\d{4}")) {
            throw new IllegalArgumentException("The password must be exactly 4 digits.");
        }
        this.password = password;
    }

    public String serialize() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}