package model;

import com.google.gson.Gson;

public class Login {
    private int op; // Login operation (5)
    private String userLogin; // User ID (7 digits)
    private String passwordLogin; // Password (4 digits)

    public Login(String userLogin, String passwordLogin) {
        this.op = 5; // Login operation
        this.userLogin = userLogin;
        this.passwordLogin = passwordLogin;
    }

    public int getOp() {
        return op;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        if (!userLogin.matches("\\d{7}")) {
            throw new IllegalArgumentException("The user ID must be exactly 7 digits.");
        }
        this.userLogin = userLogin;
    }

    public String getPasswordLogin() {
        return passwordLogin;
    }

    public void setPasswordLogin(String passwordLogin) {
        if (!passwordLogin.matches("\\d{4}")) {
            throw new IllegalArgumentException("The password must be exactly 4 digits.");
        }
        this.passwordLogin = passwordLogin;
    }

    public String serialize() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}