package model;

import com.google.gson.Gson;

public class Response {
    private String response;
    private String message;
    private String token;

    public Response(String i, String message, String token) {
        this.response = i;
        this.message = message;
        this.token = token;
    }

    public String serialize() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}
