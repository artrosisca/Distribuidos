package model;

import com.google.gson.Gson;

public class Request {
    public String op; // Operation (1 = Register, 5 = Login, 6 = Logout)
    public String name; // Name for the Register operation
    public String user; // User ID for Login/Register
    public String password; // Password for Login/Register
    public String token; // Token for Logout

    // Constructor to initialize all fields
    public Request(String name, String op, String user, String password, String token) {
        this.name = name;
        this.op = op;
        this.user = user;
        this.password = password;
        this.token = token;
    }

    // Serialize the object to JSON
    public String serialize() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }

    // Deserialize JSON to a Request object
    public static Request deserialize(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, Request.class);
    }
}