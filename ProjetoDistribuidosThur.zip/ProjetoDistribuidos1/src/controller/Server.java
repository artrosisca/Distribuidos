package controller;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.gson.*;
import model.Register;
import model.Request;
import model.Response;

public class Server extends Thread {
    private static final Logger logger = Logger.getLogger(Server.class.getName());
    private Socket clientSocket;
    public boolean server = true;
    public static List<Register> registers = new ArrayList<>();

    public static void main(String[] args) {
        BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        ServerSocket serverSocket = null;
        try {
            System.out.print("Enter the server port: ");
            int port = Integer.parseInt(stdIn.readLine());

            serverSocket = new ServerSocket(port);
            System.out.println("Server started on port " + port);

            while (true) {
                new Server(serverSocket.accept());
            }
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error starting server on port", e);
            e.printStackTrace();
        } finally {
            try {
                if (serverSocket != null) {
                    serverSocket.close();
                }
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Error closing server socket", e);
            }
        }
    }

    public Server(Socket clientSocket) {
        this.clientSocket = clientSocket;
        start();
    }

    private String processRequest(Gson gson, String inputLine) {
        Request request = gson.fromJson(inputLine, Request.class);
        return handleRequest(gson, request);
    }

    public void run() {
        try {
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            System.out.println("Connected to: " + clientSocket.getInetAddress().getHostAddress() + ":" + clientSocket.getPort());

            String inputLine;
            Gson gson = new Gson();

            while (server) {
                inputLine = in.readLine();
                System.out.println("Mensagem recebida: " + inputLine);

                String response;
                try {
                    response = processRequest(gson, inputLine);

                } catch (JsonSyntaxException e) {
                    response = new Response("999", "Invalid JSON format", null).serialize();
                }
                System.out.println("Enviando resposta: " + response);
                out.println(response);

            }

            System.out.println("Disconnecting from: " + clientSocket.getInetAddress().getHostAddress() + ":" + clientSocket.getPort());
            out.close();
            in.close();
            clientSocket.close();
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error communicating with client.", e);
        }
    }

    private String handleRequest(Gson gson, Request request) {
        return switch (request.op) {
            case "1" -> handleRegister(gson, request);
            case "5" -> handleLogin(gson, request);
            case "6" -> handleLogout(gson, request);
            default -> gson.toJson(new Response("999", "Unknown operation", null));
        };
    }

    private String handleRegister(Gson gson, Request request) {
        if (isUserExists(request.user)) {
            return gson.toJson(new Response("103", "Already exists an account with the username", null));
        } else if (isInvalidRegisterRequest(request)) {
            return gson.toJson(new Response("101", "Fields missing", null));
        } else if (isInvalidUserInfo(request)) {
            return gson.toJson(new Response("102", "Invalid information: user or password", null));
        }
        registers.add(new Register(request.name, request.user, request.password));
        return gson.toJson(new Response("100", "Successful account creation", null));
    }

    private boolean isUserExists(String user) {
        return registers.stream().anyMatch(c -> c.getUser().equals(user));
    }

    private boolean isInvalidRegisterRequest(Request request) {
        return request.user == null || request.password == null || !request.password.matches("\\d{4}")
                || request.name == null || request.name.length() > 40;
    }

    private boolean isInvalidUserInfo(Request request) {
        return !request.name.matches("[a-zA-Z0-9 ]*") || !request.password.matches("\\d{4}")
                || !request.user.matches("\\d{7}");
    }

    private String handleLogin(Gson gson, Request request) {
        if (request.user == null || request.password == null) {
            return gson.toJson(new Response("002", "Fields missing", null));
        }
        for (Register c : registers) {
            if (c.getUser().equals(request.user) && c.getPassword().equals(request.password)) {
                return gson.toJson(new Response("000", "Successful login", request.user));
            }
        }
        return gson.toJson(new Response("003", "Login failed", null));
    }

    private String handleLogout(Gson gson, Request request) {
        if (request.token == null || request.token.isEmpty()) {
            return gson.toJson(new Response("011", "Fields missing", null));
        }
        return gson.toJson(new Response("010", "Successful logout", null));
    }
}