package controller;

import model.Request;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the server IP: ");
            String serverHostname = scanner.nextLine();

            System.out.print("Enter the server port: ");
            int port = Integer.parseInt(scanner.nextLine());

            try (Socket echoSocket = new Socket(serverHostname, port);
                 PrintWriter out = new PrintWriter(echoSocket.getOutputStream(), true);
                 BufferedReader in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()))) {

                System.out.println("Connected with " + echoSocket.getInetAddress().getHostAddress() + ":" + echoSocket.getPort());

                boolean running = true;
                while (running) {
                    displayMenu();
                    int option = Integer.parseInt(scanner.nextLine());

                    switch (option) {
                        case 1:
                            register(scanner, out, in);
                            break;
                        case 2:
                            login(scanner, out, in);
                            break;
                        case 3:
                            logout(scanner, out, in);
                            break;
                        case 0:
                            running = false;
                            System.out.println("Shutting down client...");
                            break;
                        default:
                            System.out.println("Invalid option. Please try again.");
                    }
                }
            } catch (IOException e) {
                System.err.println("Error connecting to host: " + serverHostname);
                e.printStackTrace();
            }
        }
    }

    // Display menu options to the user
    private static void displayMenu() {
        System.out.println("\nSelect an option:");
        System.out.println("1 - Register");
        System.out.println("2 - Login");
        System.out.println("3 - Logout");
        System.out.println("0 - Exit");
        System.out.print("Option: ");
    }

    // Function to handle user registration
    private static void register(Scanner scanner, PrintWriter out, BufferedReader in) throws IOException {
        System.out.print("Enter the name (max 40 characters, no accents or special characters): ");
        String name = scanner.nextLine();

        System.out.print("Enter the user ID (7 digits): ");
        String user = scanner.nextLine();

        System.out.print("Enter the password (4 digits): ");
        String password = scanner.nextLine();

        sendRequest(out, in, new Request(name, "1", user, password, null));
    }

    // Function to handle user login
    private static void login(Scanner scanner, PrintWriter out, BufferedReader in) throws IOException {
        System.out.print("Enter the user ID (7 digits): ");
        String user = scanner.nextLine();

        System.out.print("Enter the password (4 digits): ");
        String password = scanner.nextLine();

        sendRequest(out, in, new Request(null, "5", user, password, null));
    }

    // Function to handle user logout
    private static void logout(Scanner scanner, PrintWriter out, BufferedReader in) throws IOException {
        System.out.print("Enter the token: ");
        String token = scanner.nextLine();

        sendRequest(out, in, new Request(null, "6", null, null, token));
    }

    // Function to send request and display server response
    private static void sendRequest(PrintWriter out, BufferedReader in, Request request) throws IOException {
        String json = request.serialize();
        System.out.println("Sending data...");
        out.println(json);

        String serverResponse = in.readLine();
        System.out.println("Server response: " + serverResponse);
    }
}